import UIKit

var str = "Hello, playground"
print(str)
